# Run Bench

GPU 서버 환경에서 LLM 성능을 자동 측정하기 위한 내부용 벤치마크 도구입니다.

## 개요

**Run Bench**는 S-CORE의 LLM Run Package 구성 요소(vLLM, LiteLLM 등)를 대상으로  
**지연시간, 처리량, 안정성, 효율성**을 자동 측정하고 리포트를 생성하는 도구입니다.

### 주요 기능

- ✅ OpenAI 호환 API 대상 부하 테스트 (`/v1/chat/completions`)
- ✅ TTFT (Time To First Token), 응답시간, 토큰 처리량 측정
- ✅ 워크로드별/모델별 성능 비교 리포트 자동 생성
- ✅ 비동기 요청 처리로 대규모 부하 시뮬레이션
- 🔄 GPU 리소스 효율 분석 (확장 예정)

## 프로젝트 구조

```
llm-benchmark/
├── scripts/              # 실행 스크립트
│   ├── run_bench.py      # 벤치마크 실행
│   ├── parse_metrics.py  # 결과 파싱 및 통계 계산
│   ├── gen_report.py     # 리포트 생성
│   └── run_bench.sh      # 전체 파이프라인 스크립트
├── configs/              # 설정 파일
│   ├── targets.yaml      # 벤치마크 대상 엔드포인트
│   ├── models.yaml       # 테스트 모델 목록
│   └── workloads.yaml    # 워크로드 패턴 정의
├── results/              # 결과 저장
│   ├── raw/              # 원시 측정 로그 (JSONL)
│   ├── summary/          # 통계 요약 (CSV)
│   └── reports/          # 최종 리포트 (Markdown)
└── .github/              # 프로젝트 문서
```

## 설치

### 방법 1: 자동 설치 스크립트 (권장)

**Run Bench**는 간편한 설치 스크립트를 제공합니다:

```bash
# 1. 저장소 클론
git clone https://github.com/lisyoen/llm-benchmark.git
cd llm-benchmark

# 2. 설치 스크립트 실행
./install.sh
```

설치 스크립트는 자동으로 다음을 수행합니다:
- 시스템 의존성 확인 및 자동 설치 (python3, python3-venv, python3-pip, git)
- Python 버전 확인 (3.11+)
- 가상환경 생성 (`venv/`)
- Python 의존성 패키지 설치
- 디렉토리 구조 생성
- 설정 파일 템플릿 생성

**지원 OS**: Ubuntu, Debian, CentOS, RHEL, Fedora

### 방법 2: 패키지 설치

배포용 패키지를 사용하는 경우:

```bash
# 패키지 파일에서 설치
pip install llm-benchmark-1.0.0.tar.gz

# 또는 GitHub에서 직접 설치
pip install git+https://github.com/lisyoen/llm-benchmark.git
```

### 방법 3: 수동 설치

```bash
# 저장소 클론
git clone https://github.com/lisyoen/llm-benchmark.git
cd llm-benchmark

# 가상환경 생성 및 활성화
python3 -m venv venv
source venv/bin/activate

# 의존성 설치
pip install -r requirements.txt

# 필요한 디렉토리 생성
mkdir -p results/raw results/summary results/reports
```

### 요구사항

- **Python**: 3.11 이상
- **OS**: Linux (Ubuntu, CentOS 등)
- **의존성 패키지**:
  - httpx >= 0.27.0 (HTTP 클라이언트)
  - pyyaml >= 6.0.1 (설정 파일 파싱)
  - pandas >= 2.2.0 (데이터 분석)

## 사용법

### 측정 방식

**Run Bench**는 실제 프로덕션 환경을 시뮬레이션하는 **부하 생성 기반 성능 측정** 방식을 사용합니다:

1. **비동기 요청 생성**: 설정된 RPS(초당 요청 수)에 맞춰 일정한 간격으로 요청을 생성
2. **동시성 제어**: 여러 요청이 동시에 처리되도록 비동기 태스크로 병렬 실행
3. **스트리밍 응답 측정**: 
   - TTFT (Time To First Token): 첫 토큰 수신까지의 시간
   - 전체 응답 시간: 요청부터 완료까지의 총 시간
   - 토큰 처리량: 생성된 토큰 수 / 생성 시간
4. **통계 분석**: Mean, Median, P95, P99 등의 백분위수 계산

### 대화형 인터페이스 예시

```bash
$ python3 scripts/run_bench_interactive.py

============================================================
🚀 Run Bench - 대화형 벤치마크 실행
============================================================

💡 팁: 엔터만 치면 기본값 사용 (5분 고부하 테스트)


📡 벤치마크 대상 서버 선택:
  → 1. spark-test: Spark GPU 서버 (DGX 테스트용)
    2. titan-test: Titan GPU 서버 (A100x8)
    3. score-main: S-Core 메인 서버 (H200x8)

선택 (1-3) [기본값: 1]: ↵

🤖 테스트 모델 선택:
  → 1. qwen3-coder-30b: Qwen3 Coder 30B (코드 생성 특화)
    2. qwen3-4b: Qwen3 4B (경량 모델)
    3. llama-3.1-70b-fp8: Llama 3.1 70B FP8 (대용량)

선택 (1-3) [기본값: 1]: ↵

⚙️  워크로드 설정:
  → 1. 기본 설정 사용 (5분 고부하 테스트)
    2. 사전 정의된 워크로드 선택
    3. 커스텀 설정

선택 (1-3) [기본값: 1]: ↵

============================================================
📋 벤치마크 설정 확인
============================================================
  서버: spark-test - Spark GPU 서버
  모델: Qwen/Qwen3-Coder-30B-A3B-Instruct
  워크로드: 5분 고부하 성능 테스트
    - 시간: 300초 (5분)
    - RPS: 20 (초당 요청 수)
    - 동시성: 50
    - 예상 총 요청: 6,000개
    - 최대 토큰: 1024
    - Temperature: 0.7
    - 프롬프트 타입: medium
============================================================

시작하시겠습니까? (Y/n) [기본값: Y]: ↵

🚀 벤치마크 시작!

=== Starting workload: high-load-5min ===
Target: spark-test, Model: Qwen/Qwen3-Coder-30B-A3B-Instruct
Duration: 300s, RPS: 20, Concurrency: 50
Expected total requests: 6000

======================================================================
⏱️  진행: 120s / 300s (40.0%) | 요청: 2,400 / 6,000 | 남은 시간: 180s (3분 0초)
```

### CLI 모드 예시

```bash
# 10분 스트레스 테스트
$ python3 scripts/run_bench_interactive.py \
    --target spark-test \
    --model qwen3-coder-30b \
    --workload stress-test

============================================================
🚀 CLI 모드로 벤치마크 실행
============================================================
  서버: spark-test - Spark GPU 서버
  모델: Qwen/Qwen3-Coder-30B-A3B-Instruct
  워크로드: 스트레스 테스트 (10분)
    - 시간: 600초 (10분)
    - RPS: 50 (초당 요청 수)
    - 동시성: 100
    - 예상 총 요청: 30,000개

⏱️  진행: 480s / 600s (80.0%) | 요청: 24,000 / 30,000 | 남은 시간: 120s (2분 0초)

✅ 완료: 29,543개, 성공: 29,234개 (98.9%)

📊 다음 명령으로 결과를 분석하세요:
  python3 scripts/parse_metrics.py results/raw/bench_spark-test_qwen3-coder-30b_stress-test_20251107_143022.jsonl
```

### 1. 설정 파일 편집

**대상 서버 설정** (`configs/targets.yaml`):
```yaml
targets:
  - name: vllm-local
    base_url: http://localhost:8000/v1
    api_key: "EMPTY"
```

**테스트 모델 설정** (`configs/models.yaml`):
```yaml
models:
  - name: llama-3.1-8b-instruct
    full_name: meta-llama/Meta-Llama-3.1-8B-Instruct
```

**워크로드 설정** (`configs/workloads.yaml`):
```yaml
workloads:
  - name: medium-load
    duration: 300  # 초
    rps: 5         # Requests Per Second
    concurrency: 10
```

### 2. 벤치마크 실행

#### 🚀 대화형 실행 (추천!)

```bash
# 가상환경 활성화
source venv/bin/activate

# 대화형 벤치마크 실행
python3 scripts/run_bench_interactive.py
```

**특징:**
- 💡 엔터만 치면 기본값 사용 (5분 고부하 테스트)
- 서버, 모델, 워크로드 선택 가능
- 커스텀 설정 지원 (시간, RPS, 토큰 수 등)

#### 🖥️ CLI 모드 실행 (자동화/스크립트용)

```bash
# 가상환경 활성화
source venv/bin/activate

# 사전 정의된 워크로드 사용
python3 scripts/run_bench_interactive.py --target spark-test --model qwen3-coder-30b --workload high-load

# 커스텀 설정으로 실행
python3 scripts/run_bench_interactive.py --target spark-test --model qwen3-coder-30b --duration 600 --rps 50 --concurrency 100

# 도움말 보기
python3 scripts/run_bench_interactive.py --help
```

**파라미터:**
- `--target`: 대상 서버 이름 (spark-test, titan-test, score-main 등)
- `--model`: 모델 이름 (qwen3-coder-30b, llama-3.1-70b-fp8 등)
- `--workload`: 워크로드 이름 (low-load, medium-load, high-load, stress-test)
- `--duration`: 테스트 시간 (초)
- `--rps`: 초당 요청 수
- `--concurrency`: 동시 요청 수
- `--max-tokens`, `--temperature`, `--prompt-type`: 추가 옵션

#### 개별 스크립트 실행 (저수준 제어)

```bash
# 벤치마크 실행
python3 scripts/run_bench.py --target vllm-local --model llama-3.1-8b-instruct --workload medium-load

# 결과 파싱
python3 scripts/parse_metrics.py results/raw/bench_*.jsonl

# 리포트 생성
python3 scripts/gen_report.py
```

#### 전체 파이프라인 실행

```bash
# 기본 설정으로 실행
./scripts/run_bench.sh

# 파라미터 지정
./scripts/run_bench.sh vllm-local llama-3.1-8b-instruct high-load
```

### 3. 결과 확인

- **원시 데이터**: `results/raw/*.jsonl`
- **통계 요약**: `results/summary/*.csv`
- **리포트**: `results/reports/benchmark_report.md`

## 측정 지표

### 1. TTFT (Time To First Token)
첫 번째 토큰이 생성될 때까지의 지연시간

- Mean, Median, P95, P99

### 2. 총 응답 시간
요청부터 응답 완료까지의 총 시간

- Mean, Median, P95, P99

### 3. 토큰 처리량
초당 생성되는 토큰 수 (tokens/sec)

- Mean, Median, P95

### 4. 성공률
전체 요청 중 성공한 요청의 비율 (%)

## 워크로드 시나리오

| 시나리오 | RPS | 동시성 | 설명 |
|---------|-----|--------|------|
| `low-load` | 1 | 1 | 개별 사용자 탐색 |
| `medium-load` | 5 | 10 | 일반적인 프로덕션 |
| `high-load` | 20 | 50 | 피크 타임 트래픽 |
| `stress-test` | 50 | 100 | 시스템 한계 측정 |

## 확장 계획

- [ ] Prometheus/Grafana 연동으로 GPU 메트릭 수집
- [ ] 토큰당 전력 효율(Tokens/W) 계산
- [ ] 여러 모델 간 비교 시각화
- [ ] CI 파이프라인 자동화 (GitHub Actions)
- [ ] HTML/PDF 리포트 생성

## 개발자 정보

**프로젝트명:** Run Bench  
**작성자:** 이창연 (AI사업그룹)  
**작성일:** 2025-11-07  
**라이선스:** MIT

## 기여

이슈 및 풀 리퀘스트 환영합니다!

---

**Note:** Run Bench는 S-CORE 내부 사용을 위해 개발되었습니다.
